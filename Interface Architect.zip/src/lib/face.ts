import * as faceapi from "face-api.js";

const MODEL_URL =
  "https://justadudewhohacks.github.io/face-api.js/models";

let loadingPromise: Promise<void> | null = null;

export function loadModels(): Promise<void> {
  if (loadingPromise) return loadingPromise;
  loadingPromise = (async () => {
    await Promise.all([
      faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
    ]);
  })();
  return loadingPromise;
}

export async function computeDescriptor(
  img: HTMLImageElement,
): Promise<Float32Array | null> {
  const res = await faceapi
    .detectSingleFace(img)
    .withFaceLandmarks()
    .withFaceDescriptor();
  return res?.descriptor ?? null;
}

export type DetectResult = {
  box: { x: number; y: number; width: number; height: number };
  label: string;
  distance: number;
};

export async function detectAndRecognize(
  input: HTMLImageElement | HTMLVideoElement | HTMLCanvasElement,
  labeled: { label: string; descriptors: Float32Array[] }[],
  threshold = 0.5,
): Promise<DetectResult[]> {
  const detections = await faceapi
    .detectAllFaces(input)
    .withFaceLandmarks()
    .withFaceDescriptors();

  const matcher =
    labeled.length > 0
      ? new faceapi.FaceMatcher(
          labeled.map(
            (l) =>
              new faceapi.LabeledFaceDescriptors(l.label, l.descriptors),
          ),
          threshold,
        )
      : null;

  return detections.map((d) => {
    const match = matcher
      ? matcher.findBestMatch(d.descriptor)
      : { label: "Unknown", distance: 1 };
    const { x, y, width, height } = d.detection.box;
    return {
      box: { x, y, width, height },
      label: match.label === "unknown" ? "Unknown" : match.label,
      distance: match.distance,
    };
  });
}

export function descriptorToArray(d: Float32Array): number[] {
  return Array.from(d);
}

export function arrayToDescriptor(a: number[]): Float32Array {
  return new Float32Array(a);
}