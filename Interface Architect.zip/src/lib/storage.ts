import { get, set } from "idb-keyval";

export type Photo = {
  id: string;
  dataUrl: string;
  descriptor: number[] | null; // null until trained
};

export type FaceClass = {
  id: string;
  name: string;
  photos: Photo[];
};

const KEY = "face-classes-v1";

export async function loadClasses(): Promise<FaceClass[]> {
  return (await get<FaceClass[]>(KEY)) ?? [];
}

export async function saveClasses(cls: FaceClass[]): Promise<void> {
  await set(KEY, cls);
}

export function uid(): string {
  return Math.random().toString(36).slice(2, 10);
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}