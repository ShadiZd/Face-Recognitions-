import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  type FaceClass,
  type Photo,
  fileToDataUrl,
  loadClasses,
  loadImage,
  saveClasses,
  uid,
} from "@/lib/storage";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Face Recognition Studio" },
      { name: "description", content: "Add classes, train, and recognize faces in your browser." },
    ],
  }),
  component: Index,
});

type Tab = "classes" | "train" | "upload" | "webcam";

const MAX_PHOTOS = 15;

function Index() {
  const [tab, setTab] = useState<Tab>("classes");
  const [classes, setClasses] = useState<FaceClass[]>([]);
  const [modelStatus, setModelStatus] = useState<
    "idle" | "loading" | "ready" | "error"
  >("idle");
  const [trainStatus, setTrainStatus] = useState<string>("");

  useEffect(() => {
    loadClasses().then(setClasses);
    setModelStatus("loading");
    import("@/lib/face")
      .then(({ loadModels }) => loadModels())
      .then(() => setModelStatus("ready"))
      .catch((e) => {
        console.error(e);
        setModelStatus("error");
      });
  }, []);

  async function persist(next: FaceClass[]) {
    setClasses(next);
    await saveClasses(next);
  }

  const totalPhotos = classes.reduce((n, c) => n + c.photos.length, 0);
  const trainedCount = classes.reduce(
    (n, c) => n + c.photos.filter((p) => p.descriptor).length,
    0,
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-6 py-5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">
              Face Recognition Studio
            </h1>
            <p className="text-sm text-muted-foreground">
              Browser-based face detection & recognition.
            </p>
          </div>
          <div className="text-sm">
            Models:{" "}
            <span
              className={
                modelStatus === "ready"
                  ? "text-green-600 font-medium"
                  : modelStatus === "error"
                    ? "text-destructive font-medium"
                    : "text-muted-foreground"
              }
            >
              {modelStatus === "ready"
                ? "Ready"
                : modelStatus === "loading"
                  ? "Loading…"
                  : modelStatus === "error"
                    ? "Failed to load"
                    : "Idle"}
            </span>
            <span className="mx-2 text-muted-foreground">•</span>
            <span className="text-muted-foreground">
              {classes.length} classes, {trainedCount}/{totalPhotos} trained
            </span>
          </div>
        </div>
        <nav className="mx-auto max-w-6xl px-6 flex gap-1 border-t border-border">
          {(
            [
              ["classes", "Classes & Photos"],
              ["train", "Train"],
              ["upload", "Test: Upload"],
              ["webcam", "Test: Webcam"],
            ] as [Tab, string][]
          ).map(([k, label]) => (
            <button
              key={k}
              onClick={() => setTab(k)}
              className={`px-4 py-3 text-sm border-b-2 -mb-px transition-colors ${
                tab === k
                  ? "border-primary text-primary font-medium"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        {tab === "classes" && (
          <ClassesTab classes={classes} onChange={persist} />
        )}
        {tab === "train" && (
          <TrainTab
            classes={classes}
            onChange={persist}
            status={trainStatus}
            setStatus={setTrainStatus}
            modelReady={modelStatus === "ready"}
          />
        )}
        {tab === "upload" && (
          <UploadTestTab classes={classes} modelReady={modelStatus === "ready"} />
        )}
        {tab === "webcam" && (
          <WebcamTestTab classes={classes} modelReady={modelStatus === "ready"} />
        )}
      </main>
    </div>
  );
}

/* ---------------- Classes Tab ---------------- */

function ClassesTab({
  classes,
  onChange,
}: {
  classes: FaceClass[];
  onChange: (c: FaceClass[]) => void;
}) {
  const [newName, setNewName] = useState("");

  function addClass() {
    const name = newName.trim();
    if (!name) return;
    onChange([...classes, { id: uid(), name, photos: [] }]);
    setNewName("");
  }

  function renameClass(id: string, name: string) {
    onChange(classes.map((c) => (c.id === id ? { ...c, name } : c)));
  }

  function deleteClass(id: string) {
    if (!confirm("Delete this class and all its photos?")) return;
    onChange(classes.filter((c) => c.id !== id));
  }

  async function addPhotos(id: string, files: FileList) {
    const cls = classes.find((c) => c.id === id);
    if (!cls) return;
    const room = MAX_PHOTOS - cls.photos.length;
    if (room <= 0) {
      alert(`Max ${MAX_PHOTOS} photos per class.`);
      return;
    }
    const slice = Array.from(files).slice(0, room);
    const photos: Photo[] = await Promise.all(
      slice.map(async (f) => ({
        id: uid(),
        dataUrl: await fileToDataUrl(f),
        descriptor: null,
      })),
    );
    onChange(
      classes.map((c) =>
        c.id === id ? { ...c, photos: [...c.photos, ...photos] } : c,
      ),
    );
  }

  function removePhoto(classId: string, photoId: string) {
    onChange(
      classes.map((c) =>
        c.id === classId
          ? { ...c, photos: c.photos.filter((p) => p.id !== photoId) }
          : c,
      ),
    );
  }

  return (
    <div className="space-y-6">
      <div className="rounded-lg border border-border bg-card p-4">
        <h2 className="font-semibold mb-2">Add a new class</h2>
        <div className="flex gap-2">
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addClass()}
            placeholder="e.g. Alice"
            className="flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary"
          />
          <button
            onClick={addClass}
            className="rounded-md bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:opacity-90"
          >
            Add class
          </button>
        </div>
      </div>

      {classes.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-8">
          No classes yet. Create one to start adding photos.
        </p>
      )}

      <div className="space-y-4">
        {classes.map((cls) => (
          <div
            key={cls.id}
            className="rounded-lg border border-border bg-card p-4"
          >
            <div className="flex items-center gap-2 mb-3">
              <input
                value={cls.name}
                onChange={(e) => renameClass(cls.id, e.target.value)}
                className="flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm font-medium outline-none focus:border-primary"
              />
              <span className="text-xs text-muted-foreground whitespace-nowrap">
                {cls.photos.length}/{MAX_PHOTOS} photos
              </span>
              <label className="cursor-pointer rounded-md border border-input bg-background px-3 py-2 text-sm hover:bg-accent">
                + Photos
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files) addPhotos(cls.id, e.target.files);
                    e.target.value = "";
                  }}
                />
              </label>
              <button
                onClick={() => deleteClass(cls.id)}
                className="rounded-md border border-destructive/40 text-destructive px-3 py-2 text-sm hover:bg-destructive/10"
              >
                Delete
              </button>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-8 gap-2">
              {cls.photos.map((p) => (
                <div key={p.id} className="relative group">
                  <img
                    src={p.dataUrl}
                    alt=""
                    className="w-full aspect-square object-cover rounded border border-border"
                  />
                  {p.descriptor && (
                    <span className="absolute top-1 left-1 bg-green-600 text-white text-[10px] px-1 rounded">
                      ✓
                    </span>
                  )}
                  <button
                    onClick={() => removePhoto(cls.id, p.id)}
                    className="absolute top-1 right-1 bg-black/70 text-white text-xs w-5 h-5 rounded opacity-0 group-hover:opacity-100"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Train Tab ---------------- */

function TrainTab({
  classes,
  onChange,
  status,
  setStatus,
  modelReady,
}: {
  classes: FaceClass[];
  onChange: (c: FaceClass[]) => void;
  status: string;
  setStatus: (s: string) => void;
  modelReady: boolean;
}) {
  const [busy, setBusy] = useState(false);

  async function train(retrainAll: boolean) {
    if (!modelReady) {
      alert("Models still loading.");
      return;
    }
    setBusy(true);
    const { computeDescriptor, descriptorToArray } = await import("@/lib/face");
    const next: FaceClass[] = JSON.parse(JSON.stringify(classes));
    let processed = 0;
    let failed = 0;
    const total = next.reduce(
      (n, c) =>
        n +
        c.photos.filter((p) => retrainAll || !p.descriptor).length,
      0,
    );
    setStatus(`Training 0/${total}…`);
    for (const cls of next) {
      for (const photo of cls.photos) {
        if (!retrainAll && photo.descriptor) continue;
        try {
          const img = await loadImage(photo.dataUrl);
          const d = await computeDescriptor(img);
          if (d) {
            photo.descriptor = descriptorToArray(d);
          } else {
            photo.descriptor = null;
            failed++;
          }
        } catch {
          failed++;
        }
        processed++;
        setStatus(`Training ${processed}/${total}…`);
      }
    }
    onChange(next);
    setStatus(
      `Done. ${processed - failed} encoded, ${failed} failed (no face found).`,
    );
    setBusy(false);
  }

  const untrained = classes.reduce(
    (n, c) => n + c.photos.filter((p) => !p.descriptor).length,
    0,
  );

  return (
    <div className="rounded-lg border border-border bg-card p-6 space-y-4">
      <div>
        <h2 className="text-lg font-semibold">Train the model</h2>
        <p className="text-sm text-muted-foreground">
          Computes a face encoding for each photo. Photos without a detectable
          face are skipped.
        </p>
      </div>
      <ul className="text-sm text-muted-foreground space-y-1">
        <li>Classes: {classes.length}</li>
        <li>
          Photos total:{" "}
          {classes.reduce((n, c) => n + c.photos.length, 0)}
        </li>
        <li>Untrained photos: {untrained}</li>
      </ul>
      <div className="flex gap-2">
        <button
          disabled={busy || untrained === 0}
          onClick={() => train(false)}
          className="rounded-md bg-primary text-primary-foreground px-4 py-2 text-sm font-medium disabled:opacity-50"
        >
          Train new photos
        </button>
        <button
          disabled={busy || classes.length === 0}
          onClick={() => train(true)}
          className="rounded-md border border-input bg-background px-4 py-2 text-sm disabled:opacity-50"
        >
          Retrain all
        </button>
      </div>
      {status && (
        <p className="text-sm font-mono bg-muted rounded p-2">{status}</p>
      )}
    </div>
  );
}

/* ---------------- Shared: labeled descriptors ---------------- */

function buildLabeled(classes: FaceClass[]) {
  return classes
    .map((c) => ({
      label: c.name,
      descriptors: c.photos
        .filter((p) => p.descriptor)
        .map((p) => new Float32Array(p.descriptor!)),
    }))
    .filter((l) => l.descriptors.length > 0);
}

/* ---------------- Upload Test Tab ---------------- */

function UploadTestTab({
  classes,
  modelReady,
}: {
  classes: FaceClass[];
  modelReady: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [busy, setBusy] = useState(false);
  const [count, setCount] = useState<number | null>(null);

  async function onFile(file: File) {
    if (!modelReady) return;
    setBusy(true);
    setCount(null);
    const url = await fileToDataUrl(file);
    const img = await loadImage(url);
    const canvas = canvasRef.current!;
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext("2d")!;
    ctx.drawImage(img, 0, 0);

    const { detectAndRecognize } = await import("@/lib/face");
    const results = await detectAndRecognize(img, buildLabeled(classes));
    drawResults(ctx, results);
    setCount(results.length);
    setBusy(false);
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card p-4 flex items-center gap-3">
        <label className="cursor-pointer rounded-md bg-primary text-primary-foreground px-4 py-2 text-sm font-medium">
          Choose image
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
          />
        </label>
        <span className="text-sm text-muted-foreground">
          {busy
            ? "Analyzing…"
            : count !== null
              ? `${count} face(s) detected`
              : "Upload an image to test the model."}
        </span>
      </div>
      <div className="rounded-lg border border-border bg-card p-4 overflow-auto">
        <canvas ref={canvasRef} className="max-w-full h-auto" />
      </div>
    </div>
  );
}

/* ---------------- Webcam Test Tab ---------------- */

function WebcamTestTab({
  classes,
  modelReady,
}: {
  classes: FaceClass[];
  modelReady: boolean;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [running, setRunning] = useState(false);
  const runningRef = useRef(false);
  const classesRef = useRef(classes);
  classesRef.current = classes;

  async function start() {
    if (!modelReady) {
      alert("Models still loading.");
      return;
    }
    const video = videoRef.current!;
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: true });
    } catch (e) {
      console.error(e);
      alert("Could not access webcam: " + (e as Error).message);
      return;
    }
    video.srcObject = stream;
    video.muted = true;
    video.playsInline = true;
    await new Promise<void>((resolve) => {
      if (video.readyState >= 1) return resolve();
      video.onloadedmetadata = () => resolve();
    });
    await video.play();
    setRunning(true);
    runningRef.current = true;
    loop();
  }

  function stop() {
    runningRef.current = false;
    setRunning(false);
    const video = videoRef.current;
    const s = video?.srcObject as MediaStream | null;
    s?.getTracks().forEach((t) => t.stop());
    if (video) video.srcObject = null;
  }

  async function loop() {
    const { detectAndRecognize } = await import("@/lib/face");
    const video = videoRef.current!;
    const canvas = canvasRef.current!;
    while (runningRef.current) {
      if (video.readyState >= 2 && video.videoWidth > 0) {
        if (canvas.width !== video.videoWidth) {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
        }
        const ctx = canvas.getContext("2d")!;
        try {
          const results = await detectAndRecognize(
            video,
            buildLabeled(classesRef.current),
          );
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          drawResults(ctx, results);
        } catch (e) {
          console.error(e);
        }
      } else {
        await new Promise((r) => setTimeout(r, 100));
      }
      await new Promise((r) => requestAnimationFrame(() => r(null)));
    }
  }

  useEffect(() => {
    return () => {
      runningRef.current = false;
      const s = videoRef.current?.srcObject as MediaStream | null;
      s?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card p-4 flex items-center gap-3">
        {!running ? (
          <button
            onClick={start}
            className="rounded-md bg-primary text-primary-foreground px-4 py-2 text-sm font-medium"
          >
            Start webcam
          </button>
        ) : (
          <button
            onClick={stop}
            className="rounded-md border border-destructive/40 text-destructive px-4 py-2 text-sm"
          >
            Stop webcam
          </button>
        )}
        <span className="text-sm text-muted-foreground">
          Press ESC-equivalent: click Stop to release the camera.
        </span>
      </div>
      <div className="rounded-lg border border-border bg-card p-4">
        <div className="relative inline-block max-w-full">
          <video
            ref={videoRef}
            className="max-w-full h-auto bg-black block"
            playsInline
            muted
            autoPlay
          />
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full pointer-events-none"
          />
        </div>
      </div>
    </div>
  );
}

/* ---------------- Drawing ---------------- */

function drawResults(
  ctx: CanvasRenderingContext2D,
  results: { box: { x: number; y: number; width: number; height: number }; label: string; distance: number }[],
) {
  ctx.lineWidth = 3;
  ctx.font = "20px sans-serif";
  for (const r of results) {
    const known = r.label !== "Unknown";
    ctx.strokeStyle = known ? "#2563eb" : "#dc2626";
    ctx.strokeRect(r.box.x, r.box.y, r.box.width, r.box.height);
    const text = known
      ? `${r.label} (${(1 - r.distance).toFixed(2)})`
      : "Unknown";
    const tw = ctx.measureText(text).width + 10;
    ctx.fillStyle = known ? "#2563eb" : "#dc2626";
    ctx.fillRect(r.box.x, Math.max(0, r.box.y - 26), tw, 26);
    ctx.fillStyle = "#ffffff";
    ctx.fillText(text, r.box.x + 5, Math.max(18, r.box.y - 8));
  }
}
